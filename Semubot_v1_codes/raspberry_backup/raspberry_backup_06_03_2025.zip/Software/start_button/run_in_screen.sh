#!/bin/bash

screen -dmS button python3 /home/semubot/Software/start_button/button.py
